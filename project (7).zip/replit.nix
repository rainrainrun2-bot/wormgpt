{pkgs}: {
  deps = [
    pkgs.python3
    pkgs.python3Packages.flask
    pkgs.python3Packages.requests
    pkgs.python3Packages.beautifulsoup4
    pkgs.python3Packages.pyautogui
  ];
}