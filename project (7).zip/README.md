# WormGPT Clone - Custom AI Assistant

A powerful AI assistant framework built with Python and Flask that you can host anywhere.

## Features
- Advanced intent detection
- Multiple response modes
- Web interface
- Session management
- Customizable behavior

## Quick Start
1. Clone this repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python main.py`
4. Access web interface at `http://localhost:5000`

## Hosting Options
- **Replit**: Upload files and run (follow ToS)
- **Heroku**: Free tier available
- **PythonAnywhere**: Easy web hosting
- **Your own server**: Full control

## Customization
Modify `WormGPTAssistant` class in `main.py` to change:
- Response logic
- User interface
- Additional features
- Integration with APIs

## Legal Notice
This tool is for educational and legitimate purposes only. Users are responsible for complying with all applicable laws.