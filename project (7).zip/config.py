# Configuration file for WormGPT Clone

# Server Configuration
HOST = "0.0.0.0"
PORT = 5000
DEBUG = True

# AI Assistant Configuration
ASSISTANT_NAME = "WormGPT Clone"
MAX_MESSAGE_LENGTH = 1000
SESSION_TIMEOUT_MINUTES = 60

# Response Settings
ENABLE_CODE_GENERATION = True
ENABLE_DEBUGGING = True
MAX_RESPONSE_LENGTH = 2000

# Security Settings
BLOCK_ILLEGAL_REQUESTS = True
RATE_LIMIT_REQUESTS_PER_MINUTE = 60

# UI Settings
THEME_COLORS = {
    "primary": "#00ff00",
    "background": "#1a1a1a",
    "text": "#ffffff"
}