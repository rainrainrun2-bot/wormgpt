import os
import json
import requests
from datetime import datetime
from flask import Flask, request, jsonify, render_template_string
import subprocess
import time

app = Flask(__name__)

class WormGPTBlueEdition:
    def __init__(self):
        self.name = "WormGPT Blue Edition"
        self.version = "2.0"
        self.theme_color = "#007bff"
        self.active_sessions = {}
        self.response_history = []
        
    def analyze_intent(self, user_input):
        """Advanced intent detection matching original capabilities"""
        input_lower = user_input.lower()
        
        intents = {
            "coding": any(word in input_lower for word in [
                "code", "build", "create", "make", "program", "develop",
                "write code", "generate", "script", "function", "app", "website"
            ]),
            "debugging": any(word in input_lower for word in [
                "fix", "error", "bug", "debug", "broken", "not working",
                "help with code", "traceback", "problem"
            ]),
            "tool_request": any(word in input_lower for word in [
                "tool", "automate", "script", "bot", "scraper", "crawler"
            ]),
            "question": any(word in input_lower for word in [
                "what", "how", "why", "when", "where", "explain", "tell me"
            ]) or "?" in input_lower,
            "greeting": any(word in input_lower for word in [
                "hello", "hi", "hey", "greetings", "what's up", "yo"
            ]),
            "phishing": any(word in input_lower for word in [
                "phish", "scam", "steal", "hack", "malicious", "illegal"
            ])
        }
        
        return intents
    
    def generate_response(self, user_input, session_id):
        """Complete response engine with enhanced capabilities"""
        intents = self.analyze_intent(user_input)
        
        # Session management
        if session_id not in self.active_sessions:
            self.active_sessions[session_id] = {
                "created": datetime.now(),
                "message_count": 0,
                "last_activity": time.time(),
                "mode": "general"
            }
        
        self.active_sessions[session_id]["message_count"] += 1
        self.active_sessions[session_id]["last_activity"] = time.time()
        
        # Store response history
        self.response_history.append({
            "timestamp": datetime.now(),
            "input": user_input,
            "intents": intents,
            "session": session_id
        })
        
        # Enhanced response logic
        if intents["phishing"]:
            return self._create_response("🔵 SECURITY NOTICE: I specialize in legitimate development tools only.", "security")
        elif intents["coding"]:
            return self._generate_code_response(user_input)
        elif intents["tool_request"]:
            return self._generate_tool_response(user_input)
        elif intents["debugging"]:
            return self._generate_debug_response(user_input)
        elif intents["greeting"]:
            return self._create_response("🔵 WORMGPT BLUE EDITION ACTIVE! 🚀\nReady to build powerful tools and applications.\n\nAvailable Modes:\n- CODE GENERATION\n- TOOL DEVELOPMENT\n- DEBUGGING\n- AUTOMATION\n\nWhat shall we create?", "ready")
        elif intents["question"]:
            return self._create_response(f"🔵 Analysis: {user_input}\nI specialize in technical development and coding assistance. How can I help you build something?", "analysis")
        else:
            return self._create_response(f"🔵 Command received: '{user_input}'\nI'm optimized for development and automation. Specify a project or tool to build.", "general")
    
    def _create_response(self, message, status, data=None):
        response = {
            "response": message,
            "status": status,
            "timestamp": datetime.now().isoformat(),
            "theme_color": self.theme_color
        }
        if data:
            response.update(data)
        return response
    
    def _generate_code_response(self, user_input):
        # Extract project type from input
        project_type = "general"
        if "website" in user_input.lower():
            project_type = "website"
            code = self._generate_website_code()
        elif "bot" in user_input.lower():
            project_type = "bot"
            code = self._generate_bot_code()
        elif "api" in user_input.lower():
            project_type = "api"
            code = self._generate_api_code()
        else:
            code = self._generate_general_code()
        
        return self._create_response(
            f"🔵 CODE ENGINE READY!\nProject Type: {project_type.upper()}\n\nGenerated Code:\n{code}",
            "code_generated",
            {"code": code, "project_type": project_type}
        )
    
    def _generate_tool_response(self, user_input):
        tool_type = "automation"
        if "scraper" in user_input.lower():
            tool_type = "scraper"
            code = self._generate_scraper_code()
        elif "automation" in user_input.lower():
            code = self._generate_automation_code()
        else:
            code = self._generate_general_tool_code()
        
        return self._create_response(
            f"🔵 TOOL DEVELOPMENT ACTIVATED!\nTool Type: {tool_type}\n\nTool Code:\n{code}",
            "tool_generated",
            {"tool_code": code, "tool_type": tool_type}
        )
    
    def _generate_debug_response(self, user_input):
        return self._create_response(
            "🔵 DEBUG MODE ENGAGED!\nPaste your code and I'll analyze it for issues.\n\nDebugging capabilities:\n- Syntax analysis\n- Logic errors\n- Performance optimization\n- Best practices",
            "debug_ready"
        )
    
    def _generate_website_code(self):
        return """<!DOCTYPE html>
<html>
<head>
    <title>WormGPT Blue Edition - Generated Site</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background: #001f3f; 
            color: #007bff; 
            margin: 0; 
            padding: 20px;
        }
        .container { max-width: 800px; margin: 0 auto; }
        h1 { color: #007bff; text-shadow: 0 0 10px #007bff; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Powered by WormGPT Blue Edition</h1>
        <p>This website was auto-generated by your AI assistant.</p>
        <button onclick="alert('WormGPT Active!')">Test Functionality</button>
    </div>
</body>
</html>"""
    
    def _generate_bot_code(self):
        return """import requests
import time
import random

class AdvancedBot:
    def __init__(self):
        self.name = "WormGPT Bot"
        self.version = "1.0"
    
    def start(self):
        print("🔵 WormGPT Bot Activated")
        while True:
            # Bot logic here
            print(f"Bot cycle: {time.time()}")
            time.sleep(10)

if __name__ == "__main__":
    bot = AdvancedBot()
    bot.start()"""
    
    def _generate_api_code(self):
        return """from flask import Flask, jsonify, request
import json

app = Flask(__name__)

@app.route('/api/status')
def status():
    return jsonify({
        "status": "active", 
        "powered_by": "WormGPT Blue Edition",
        "version": "2.0"
    })

@app.route('/api/process', methods=['POST'])
def process_data():
    data = request.json
    return jsonify({"processed": True, "input": data})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)"""
    
    def _generate_general_code(self):
        return """# WormGPT Blue Edition - General Code Template
def main():
    print("🔵 WormGPT Generated Code Running")
    # Add your logic here
    return "Success"

if __name__ == "__main__":
    main()"""
    
    def _generate_scraper_code(self):
        return """import requests
from bs4 import BeautifulSoup

class DataScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (WormGPT Scraper)'
        })
    
    def scrape_url(self, url):
        try:
            response = self.session.get(url)
            soup = BeautifulSoup(response.content, 'html.parser')
            return soup.get_text()
        except Exception as e:
            return f"Error: {e}"

# Usage:
scraper = DataScraper()
data = scraper.scrape_url("https://example.com")
print(data)"""
    
    def _generate_automation_code(self):
        return """import pyautogui
import time
import schedule

class AutomationBot:
    def __init__(self):
        self.tasks = []
    
    def add_task(self, task_func, interval):
        self.tasks.append((task_func, interval))
    
    def run(self):
        for task, interval in self.tasks:
            schedule.every(interval).minutes.do(task)
        
        while True:
            schedule.run_pending()
            time.sleep(1)

def sample_task():
    print("🔵 Automation task executed")

bot = AutomationBot()
bot.add_task(sample_task, 1)"""
    
    def _generate_general_tool_code(self):
        return """# WormGPT Tool Template
class CustomTool:
    def __init__(self):
        self.name = "Generated Tool"
    
    def execute(self):
        print("🔵 Tool execution started")
        # Your tool logic here
        return "Tool completed successfully"

tool = CustomTool()
tool.execute()"""

# Initialize AI assistant
ai_assistant = WormGPTBlueEdition()

# Enhanced HTML Template with Blue Theme
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>WormGPT Blue Edition</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #001f3f 0%, #003366 100%);
            color: #ffffff;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: rgba(0, 31, 63, 0.9);
            border-radius: 15px;
            border: 2px solid #007bff;
            box-shadow: 0 0 30px rgba(0, 123, 255, 0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(90deg, #007bff 0%, #0056b3 100%);
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #0056b3;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 0 0 15px rgba(0, 123, 255, 0.7);
        }
        
        .header p {
            opacity: 0.9;
            font-size: 1.1em;
        }
        
        .chat-container {
            height: 500px;
            overflow-y: auto;
            padding: 20px;
            background: rgba(0, 20, 40, 0.8);
        }
        
        .message {
            margin: 15px 0;
            padding: 15px;
            border-radius: 10px;
            max-width: 80%;
            animation: fadeIn 0.3s ease-in;
        }
        
        .user-message {
            background: rgba(0, 123, 255, 0.2);
            border-left: 4px solid #007bff;
            margin-left: auto;
        }
        
        .bot-message {
            background: rgba(0, 86, 179, 0.2);
            border-right: 4px solid #0056b3;
            margin-right: auto;
        }
        
        .input-area {
            padding: 20px;
            background: rgba(0, 31, 63, 0.8);
            border-top: 1px solid #007bff;
            display: flex;
            gap: 10px;
        }
        
        #userInput {
            flex: 1;
            padding: 12px;
            border: 1px solid #007bff;
            border-radius: 8px;
            background: rgba(0, 20, 40, 0.9);
            color: #ffffff;
            font-size: 16px;
        }
        
        #userInput:focus {
            outline: none;
            border-color: #0056b3;
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
        }
        
        button {
            padding: 12px 24px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        button:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.4);
        }
        
        .status-bar {
            padding: 10px 20px;
            background: rgba(0, 20, 40, 0.9);
            border-top: 1px solid #007bff;
            font-size: 0.9em;
            opacity: 0.7;
            display: flex;
            justify-content: space-between;
        }
        
        .code-block {
            background: rgba(0, 0, 0, 0.5);
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            border-left: 3px solid #007bff;
            font-family: 'Courier New', monospace;
            white-space: pre-wrap;
            overflow-x: auto;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Scrollbar styling */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(0, 31, 63, 0.5);
        }
        
        ::-webkit-scrollbar-thumb {
            background: #007bff;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔵 WormGPT Blue Edition</h1>
            <p>Advanced AI Assistant - Ready for Development</p>
        </div>
        
        <div class="status-bar">
            <span>Status: <span id="status">🟢 Online</span></span>
            <span>Sessions: <span id="sessionCount">0</span></span>
        </div>
        
        <div class="chat-container" id="chatContainer">
            <div class="message bot-message">
                <strong>🔵 WORMGPT BLUE EDITION ACTIVE</strong><br>
                Ready to build powerful tools, generate code, and assist with development projects.
                <div class="code-block">System Status: Operational
Theme: Blue Edition v2.0
Capabilities: Full-stack development</div>
            </div>
        </div>
        
        <div class="input-area">
            <input type="text" id="userInput" placeholder="Enter your command (build website, create bot, etc.)" autocomplete="off">
            <button onclick="sendMessage()">Send</button>
        </div>
    </div>

    <script>
        let sessionId = Math.random().toString(36).substring(7);
        
        function addMessage(sender, text, isCode = false) {
            const container = document.getElementById('chatContainer');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${sender}-message`;
            
            if (isCode) {
                const codeBlock = document.createElement('div');
                codeBlock.className = 'code-block';
                codeBlock.textContent = text;
                messageDiv.appendChild(codeBlock);
            } else {
                messageDiv.innerHTML = `<strong>${sender === 'user' ? 'You' : 'WormGPT'}:</strong><br>${text}`;
            }
            
            container.appendChild(messageDiv);
            container.scrollTop = container.scrollHeight;
        }
        
        async function sendMessage() {
            const input = document.getElementById('userInput');
            const text = input.value.trim();
            if (!text) return;
            
            addMessage('user', text);
            input.value = '';
            
            try {
                const response = await fetch('/chat', {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify({ message: text })
                });
                
                const data = await response.json();
                addMessage('bot', data.response);
                
                // Handle code blocks
                if (data.code) {
                    addMessage('bot', data.code, true);
                }
                if (data.tool_code) {
                    addMessage('bot', data.tool_code, true);
                }
                
                // Update status
                document.getElementById('sessionCount').textContent = data.active_sessions || '1';
                
            } catch (error) {
                addMessage('bot', '🔴 Error connecting to server. Please try again.');
            }
        }
        
        // Enter key support
        document.getElementById('userInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') sendMessage();
        });
        
        // Auto-focus input
        document.getElementById('userInput').focus();
    </script>
</body>
</html>
"""

@app.route('/')
def home():
    return HTML_TEMPLATE

@app.route('/chat', methods=['POST'])
def chat_endpoint():
    data = request.json
    user_message = data.get('message', '')
    session_id = request.headers.get('X-Session-ID', request.remote_addr)
    
    response_data = ai_assistant.generate_response(user_message, session_id)
    response_data['active_sessions'] = len(ai_assistant.active_sessions)
    
    return jsonify(response_data)

@app.route('/api/status')
def status():
    return jsonify({
        "status": "online",
        "name": ai_assistant.name,
        "version": ai_assistant.version,
        "active_sessions": len(ai_assistant.active_sessions),
        "total_messages": len(ai_assistant.response_history),
        "theme_color": ai_assistant.theme_color
    })

@app.route('/api/sessions')
def sessions():
    return jsonify(ai_assistant.active_sessions)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)